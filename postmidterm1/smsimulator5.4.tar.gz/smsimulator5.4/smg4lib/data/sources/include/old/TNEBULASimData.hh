#ifndef TNEBULASIMDATA_HH
#define TNEBULASIMDATA_HH

#include <vector>
#include "TSimData.hh"

typedef std::vector<TSimData> TNEBULASimDataArray;
extern TNEBULASimDataArray* gNEBULASimDataArray;

#endif


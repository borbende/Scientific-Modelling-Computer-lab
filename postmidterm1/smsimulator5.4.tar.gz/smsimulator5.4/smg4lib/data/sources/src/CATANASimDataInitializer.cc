#include <iostream>

#include <TFile.h>
#include <TTree.h>

#include "CATANASimDataInitializer.hh"

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
CATANASimDataInitializer::CATANASimDataInitializer(TString name)
  : SimDataInitializer(name)
{
  fDataStore = false; // default
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
CATANASimDataInitializer::~CATANASimDataInitializer()
{;}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
int CATANASimDataInitializer::Initialize()
{
  fSimDataArray = new TClonesArray("TSimData",256);
  fSimDataArray->SetName("CATANASimData");
  fSimDataArray->SetOwner();

  return 0;
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
int CATANASimDataInitializer::DefineBranch(TTree *tree)
{
  if(fDataStore) tree->Branch(fSimDataArray->GetName(), &fSimDataArray);
  return 0;
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
int CATANASimDataInitializer::ClearBuffer()
{
  fSimDataArray->Delete();
  return 0;
}



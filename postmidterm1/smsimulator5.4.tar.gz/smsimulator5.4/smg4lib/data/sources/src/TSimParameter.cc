#include "TSimParameter.hh"

ClassImp(TSimParameter)

TSimParameter::TSimParameter(TString name)
{
  SetName(name);
}
TSimParameter::~TSimParameter()
{;}

rm g4*eps
rm g4*prim
rm g4*wrl


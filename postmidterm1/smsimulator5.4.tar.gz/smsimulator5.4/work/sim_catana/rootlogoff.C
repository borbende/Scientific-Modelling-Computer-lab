#ifndef __CINT__
#include "TArtAnaLoopManager.hh"
#endif

void rootlogoff(){
  stop();
}


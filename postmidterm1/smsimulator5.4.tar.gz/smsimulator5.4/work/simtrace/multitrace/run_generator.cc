{
  gSystem->CompileMacro("./multitrace/GenerateForMultitrace.cc","g");
  GenerateForMultitrace();
}

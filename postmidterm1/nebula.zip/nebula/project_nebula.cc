#include "DetectorConstruction.hh"
#include "ActionInitialization.hh"

#include "G4RunManagerFactory.hh"

#include "G4UImanager.hh"
#include "G4PhysListFactory.hh"

#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"

#include "Randomize.hh"


int main(int argc,char** argv)
{
  // Detect interactive mode (if no arguments) and define UI session
  //
  G4UIExecutive* ui = 0;
  if ( argc == 2 ) {
    ui = new G4UIExecutive(argc, argv);
  }

  // Optionally: choose a different Random engine...
  // G4Random::setTheEngine(new CLHEP::MTwistEngine);
  
  // Construct the default run manager
  //
  auto* runManager =
    G4RunManagerFactory::CreateRunManager(G4RunManagerType::Default);

  // Set mandatory initialization classes
  //
  // Detector construction
  runManager->SetUserInitialization(new DetectorConstruction());

  std::vector<std::string> physics = {
        "QBBC",
        "QGSP_BERT_HP",
        "QGSP_BIC_HP",
        "QGSP_INCLXX",
        "QGSP_INCLXX_HP"
  };
  
  // Physics list
  G4PhysListFactory *physListFactory = new G4PhysListFactory();
  G4VUserPhysicsList *physicsList = 
              physListFactory->GetReferencePhysList(argv[1]);
  physicsList->SetVerboseLevel(1);
  runManager->SetUserInitialization(physicsList);
    
  // User action initialization
  runManager->SetUserInitialization(new ActionInitialization());
  
  // Initialize visualization
  //
  G4VisManager* visManager = new G4VisExecutive;
  // G4VisExecutive can take a verbosity argument - see /vis/verbose guidance.
  // G4VisManager* visManager = new G4VisExecutive("Quiet");
  visManager->Initialize();

  // Get the pointer to the User Interface manager
  G4UImanager* UImanager = G4UImanager::GetUIpointer();

  	UImanager->ApplyCommand("/vis/open OGL");   //Activates display.
	UImanager->ApplyCommand("/vis/viewer/set/viewpointVector 1 1 1");
	//Changes initial position of look.
	UImanager->ApplyCommand("/vis/drawVolume"); //Draws the volume.
	UImanager->ApplyCommand("/vis/viewer/set/autoRefresh true"); //Updates display.
	UImanager->ApplyCommand("/vis/scene/add/trajectories smooth"); //Shows particle trajectory.
	UImanager->ApplyCommand("/vis/scene/endofEventAction accumulate"); //Accumulates all events that happen in one run.
	
	
	ui->SessionStart();	
	
	
	return 0;
}
